@extends('master')
@section('style')
    <style>
        .bg-light-gray {
            background-color: #f7f7f7;
        }
        .table-bordered thead td, .table-bordered thead th {
            border-bottom-width: 2px;
        }
        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6;
        }
        .table-bordered td, .table-bordered th {
            border: 1px solid #dee2e6;
        }


        .bg-white.box-shadow {
            box-shadow: 0px 5px 0px 0px white
        }
        .bg-white {
            background-color: white;
        }
        .center{
            text-align: center;
        }

        .padding-15px-lr {
            padding-left: 110px;
            padding-right: 110px;
        }
        .padding-5px-tb {
            padding-top: 5px;
            padding-bottom: 5px;
        }
        .padding{
            padding-top: 5px;
            padding-bottom: 5px;
            padding-left: 98px;
            padding-right: 98px;
        }
        .padding1{
            padding-top: 5px;
            padding-bottom: 5px;
            padding-left: 92px;
            padding-right: 92px;
        }
        .margin-10px-bottom {
            margin-bottom: 10px;
        }
        .border-radius-5 {
            border-radius: 5px;
        }

        .margin-10px-top {
            margin-top: 10px;
        }
        .font-size14 {
            font-size: 14px;
        }

        .text-light-gray {
            color: #d6d5d5;
        }
        .font-size13 {
            font-size: 13px;
        }

        .table-bordered td, .table-bordered th {
            border: 1px solid #dee2e6;
        }
        .table td, .table th {
            padding: .75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }

    </style>
@endsection
@section('content')
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <span class="dashboard">TimeTable</span>
            </div>
            <div class="search-box">

            </div>
        </nav>

        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 1 Morning</div>
                    <br>
                        <div class="timetable-img text-center">
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered-less text-center">
                                <thead>
                                <tr class="bg-light-gray">
                                    <th class="text-uppercase">Time
                                    </th>
                                    <th class="text-uppercase">Monday</th>
                                    <th class="text-uppercase">Tuesday</th>
                                    <th class="text-uppercase">Wednesday</th>
                                    <th class="text-uppercase">Thursday</th>
                                    <th class="text-uppercase">Friday</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="align-middle center">8:00am</td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                        <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                        <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                        <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                    </td>

                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                        <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                        <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">C++ I</div>
                                        <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                        <div class="margin-10px-top font-size14 padding1">Network</div>
                                        <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                    </td>

                                </tr>

                                <tr>
                                    <td class="align-middle">9:30am</td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                        <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                        <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                        <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                    </td>

                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                        <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                        <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">C++ I</div>
                                        <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                        <div class="margin-10px-top font-size14 padding1">Network</div>
                                        <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="align-middle">9:45am</td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                        <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                        <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                        <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                    </td>

                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                        <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                        <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                        <div class="margin-10px-top font-size14 padding">C++ I</div>
                                        <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                    </td>
                                    <td>
                                        <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                        <div class="margin-10px-top font-size14 padding1">Network</div>
                                        <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                    </td>
                                </tr>


                                </tbody>
                            </table>
                        </div>
                    </div>
            </div>
        </div>


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 1 Afternoon</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">2:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">3:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">3:45pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 1 Evening</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">5:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">7:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">7:15pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Principles Of Economy</div>
                                    <div class="font-size13 text-light-gray padding">Peng Marady</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Design</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Lekena</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">English For Computer</div>
                                    <div class="font-size13 text-light-gray padding1">Hok Lekena</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C++ I</div>
                                    <div class="font-size13 text-light-gray padding">Samok Punleu</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>
                            </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


{{--        year2--}}


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 2 Morning</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">8:00am</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">9:30am</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">9:45am</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 2 Afternoon</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">2:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">3:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">3:45pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 2 Evening</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">5:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">7:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">7:15pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Database Management System</div>
                                    <div class="font-size13 text-light-gray padding">Sao Yang</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Computer Networking</div>
                                    <div class="font-size13 text-light-gray padding1">Lin Senglek</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Data Algorithms Structure</div>
                                    <div class="font-size13 text-light-gray padding1">Phoeung Channa</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">C# I</div>
                                    <div class="font-size13 text-light-gray padding">Ho Mony</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Web Development</div>
                                    <div class="font-size13 text-light-gray padding1">Keo Tongheng</div>
                                </td>
                            </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

{{--        year3--}}


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 3 Evening</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">5:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP I</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Client Server</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Ecommerce</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing I</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">System Analysis</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">7:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP I</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Client Server</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Ecommerce</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing I</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">System Analysis</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">7:15pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP I</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Client Server</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Ecommerce</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing I</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">System Analysis</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


{{--        year4--}}


        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="title">Year 4 Evening</div>
                    <br>
                    <div class="timetable-img text-center">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered-less text-center">
                            <thead>
                            <tr class="bg-light-gray">
                                <th class="text-uppercase">Time
                                </th>
                                <th class="text-uppercase">Monday</th>
                                <th class="text-uppercase">Tuesday</th>
                                <th class="text-uppercase">Wednesday</th>
                                <th class="text-uppercase">Thursday</th>
                                <th class="text-uppercase">Friday</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="align-middle center">5:30pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP II</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Mobile Development</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing II</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Oracle Database</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>

                            </tr>

                            <tr>
                                <td class="align-middle">7:00pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP II</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Mobile Development</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing II</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Oracle Database</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>
                            </tr>

                            <tr>
                                <td class="align-middle">7:15pm</td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16 xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">OOP II</div>
                                    <div class="font-size13 text-light-gray padding">Pen Socheat</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Yoga</span>
                                    <div class="margin-10px-top font-size14 padding1">Network</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Rotha</div>
                                </td>

                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Music</span>
                                    <div class="margin-10px-top font-size14 padding1">Mobile Development</div>
                                    <div class="font-size13 text-light-gray padding1">Khan Sokha</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Dance</span>
                                    <div class="margin-10px-top font-size14 padding">Java Programing II</div>
                                    <div class="font-size13 text-light-gray padding">Try Sothea</div>
                                </td>
                                <td>
                                    <span class="bg-white padding-5px-tb padding-15px-lr border-radius-5 margin-10px-bottom text-white font-size16  xs-font-size13">Art</span>
                                    <div class="margin-10px-top font-size14 padding1">Oracle Database</div>
                                    <div class="font-size13 text-light-gray padding1">Rin Vannet</div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>





    </section>
@endsection
