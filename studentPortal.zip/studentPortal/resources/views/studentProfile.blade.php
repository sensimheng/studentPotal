@extends('master')
@section('content')
    @section('style')
        <head>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
            <link rel="stylesheet" href="https://unpkg.com/flowbite@1.5.3/dist/flowbite.min.css" />
        </head>
        <style>
            .size{
                font-size: 130px;
            }
        </style>
        @endsection
    <form action="{{url('profile/'.$show->id)}}" METHOD="POST">
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <span class="dashboard">Student Detail</span>
            </div>
        </nav>
        <div class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <a href="{{url('student')}}" class="focus:outline-none text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:focus:ring-yellow-900">Back</a>
                    <div class="student-profile py-4">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="card shadow-sm">
                                        <div class="card-header bg-transparent text-center">
                                            <i class='bx bxs-user size'></i>
                                            <h3>{{$show->Firstname}} {{$show->Lastname}}</h3>
                                        </div>
                                        <div class="card-body">
                                            <p class="mb-0"><strong class="pr-1">ID:</strong>{{$show->id}}</p>
                                            <p class="mb-0"><strong class="pr-1">Sex:</strong>{{$show->Sex}}</p>
                                            <p class="mb-0"><strong class="pr-1">Year:</strong>{{$show->yearID}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="card shadow-sm">
                                        <div class="card-body pt-0">
                                            <table class="table table-bordered-less">
                                                <tr>
                                                    <th width="30%">Date Of Birth</th>
                                                    <td width="2%">:</td>
                                                    <td>{{$show->DOB}}</td>
                                                </tr>
                                                <tr>
                                                    <th width="30%">Place Of Birth	</th>
                                                    <td width="2%">:</td>
                                                    <td>{{$show->POB}}</td>
                                                </tr>
                                                <tr>
                                                    <th width="30%">Shift</th>
                                                    <td width="2%">:</td>
                                                    <td>{{$show->Shift}}</td>
                                                </tr>
                                                <tr>
                                                    <th width="30%">PhoneNumber</th>
                                                    <td width="2%">:</td>
                                                    <td>{{$show->PhoneNumber}}</td>
                                                </tr>
                                                <tr>
                                                    <th width="30%">Email</th>
                                                    <td width="2%">:</td>
                                                    <td>{{$show->Email}}</td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div style="height: 26px"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
            </div>
        </div>
    </section>
    </form>
@endsection
