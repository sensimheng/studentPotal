@extends('master')
@section('content')
    @php
        $year1 = 'Year 1';
      $year2 = 'Year 2';
      $year3 = 'Year 3';
      $year4 = 'Year 4';
         $all = 'Select Year';
    @endphp
    @section('style')
        <style>
            .dropbtn {
                background-color: whitesmoke;
                color: black;
                padding: 10px;
                font-size: 18px;
                border: none;
                border-radius: 6px;
                height: 50px;
                min-width: 190px;
                max-width: 550px;
                position: relative;
            }

            .dropdown {
                position: relative;
                display: inline-block;
            }

            .dropdown-content {
                display: none;
                position: absolute;
                background-color: #f1f1f1;
                min-width: 160px;
                overflow: auto;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
            }

            .dropdown-content a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                min-width: 190px;
                max-width: 550px;
            }

            .dropdown a:hover {background-color: #ddd;}

            .show {display: block;}
        </style>
    @endsection
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <span class="dashboard">StudentList</span>
            </div>
            <!-- select  -->
            <div class="dropdown">
                <button onclick="myFunction()" class="dropbtn">
                    {{$year}}
                </button>
                <div id="myDropdown" class="dropdown-content">
                    <a href="{{('final?')}}">Year1</a>
                    <a href="{{('final?yearf='.$year2)}}">Year2</a>
                    <a href="{{('final?yearf='.$year3)}}">Year3</a>
                    <a href="{{('final?yearf='.$year4)}}">Year4</a>
                </div>
            </div>
            <!-- End Select -->
        </nav>

        <div id="table" class="home-content">
            <div class="sales-boxes">
                <div class="recent-sales box">
                    <div class="sales-details">


                        <ul class="details">
                            <li class="topic">ID</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->ID}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Firstname</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->Firstname}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Lastname</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->Lastname}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Sex</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->Sex}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Subject</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->subjectName}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Midterm</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->Score}}</a></li>
                            @endforeach
                        </ul>

                        <ul class="details">
                            <li class="topic">Final</li>
                            @foreach($final as $f)
                                <li><a href="#">{{$f->score}}</a></li>
                            @endforeach
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
@endsection


