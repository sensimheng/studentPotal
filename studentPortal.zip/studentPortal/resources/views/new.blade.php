@extends('master')
@section('content')
    @section('style')
        <style>
            .center {
                display: block;
                margin-left: auto;
                margin-right: auto;
                width: 40%;
            }
            .img{
                border-radius: 20px;
            }
        </style>
    @endsection
        <section class="home-section">
            <nav>
                <div class="sidebar-button">
                    <span class="dashboard">Student News</span>
                </div>
            </nav>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news8.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/photo_2022-11-07_23-46-25.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/photo_2022-11-07_23-46-54.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news5.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/new6.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news9.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news10.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/new7.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news11.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news12.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news13.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news14.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news15.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news16.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news17.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="home-content">
                <div class="sales-boxes">
                    <div class="recent-sales box">
                        <div class="sales-details">

                            <ul class="details center">
                                <img src="image/news18.jpg" class="img">
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


        </section>
    @endsection
