<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('Style/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Style/style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css')); ?>">
</head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bxs-school' ></i>
        <span class="logo_name">StudentPortal</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="<?php echo e(url('student')); ?>" class="active">
                <i class='bx bx-notepad'></i>
                <span class="links_name">StudentList</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('news')); ?>">
                <i class='bx bx-news' ></i>
                <span class="links_name">News</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('timeTable')); ?>">
                <i class='bx bx-table' ></i>
                <span class="links_name">TimeTable</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('midterm')); ?>">
                <i class='bx bx-pie-chart-alt-2' ></i>
                <span class="links_name">Midterm Score</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('final')); ?>">
                <i class='bx bx-coin-stack' ></i>
                <span class="links_name">Final Score</span>
            </a>
        </li>
        <li class="log_out">
            <a href="<?php echo e(url('/')); ?>">
                <i class='bx bx-log-out'></i>
                <span class="links_name">Log out</span>
            </a>
        </li>
    </ul>
</div>
<script>
    let sidebar = document.querySelector(".sidebar");
    let sidebarBtn = document.querySelector(".sidebarBtn");
    sidebarBtn.onclick = function() {
        sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
        }else
            sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\studentPortal\studentPortal\resources\views/nav.blade.php ENDPATH**/ ?>