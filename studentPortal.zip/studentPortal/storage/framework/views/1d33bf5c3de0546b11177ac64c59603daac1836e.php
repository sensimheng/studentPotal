<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="Style/login.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Portal</title>
</head>
<body>
<div class="login-form-container">
    <form action="check" method="POST">
        <h3>Login</h3>
        <span>Username</span>
        <input type="text" name="username" class="box" placeholder="enter your username"  autofocus required>

        <span>Password</span>
        <input type="password" name="password" class="box" placeholder="enter your password"  required>
        <a href="<?php echo e(url('student')); ?>" name="submit" class="btn">login</a>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\studentPortal\studentPortal\resources\views/login.blade.php ENDPATH**/ ?>