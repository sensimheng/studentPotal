<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Style/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Style/style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Style/style2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://unpkg.com/flowbite@1.5.3/dist/flowbite.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://unpkg.com/swiper@7/swiper-bundle.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css')); ?>">
</head>
<body>
<?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('style'); ?>
<script src="<?php echo e(asset('Style/style3.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\studentPortal\studentPortal\resources\views/master.blade.php ENDPATH**/ ?>