<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('midterm', function (Blueprint $table) {

            $table->integer('midtermID')->primary();
            $table->integer('studentID');
            $table->integer('subjectID');
            $table->integer('yearID');
            $table->integer('Homework');
            $table->integer('Notebook');
            $table->integer('ClassParticipation');
            $table->integer('Assignment');
            $table->integer('Presentation');
            $table->integer('Score');
            $table->timestamps();
            $table->foreign('studentID')->references('studentID')->on('students')->onDelete('cascade');
            $table->foreign('subjectID')->references('subjectID')->on('subjects')->onDelete('cascade');
            $table->foreign('yearID')->references('yearID')->on('years')->onDelete('cascade');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('midterm');
    }
};
