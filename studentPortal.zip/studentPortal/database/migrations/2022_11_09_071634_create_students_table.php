<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->integer('studentID')->primary();
            $table->string('ID');
            $table->string('Firstname');
            $table->string('Lastname');
            $table->string('Sex');
            $table->integer('yearID');
            $table->date('DOB');
            $table->string('POB');
            $table->string('Address');
            $table->string('Semester');
            $table->string('Shift');
            $table->string('PhoneNumber');
            $table->string('Email');
            $table->timestamps();
            $table->foreign('yearID')->references('yearID')->on('years')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
};
