<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\detail;
use Illuminate\Http\Request;
use App\Models\portal;
use App\Models\year;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class portalController extends Controller
{
    public function index(){
        return view('login');
    }

    public function show($id){
        $show = detail::find($id);
        return view('studentProfile',compact('show'));
    }
    public function student(Request $request)
    {
        $year1 = 'Year 1';
        $year2 = 'Year 2';
        $year3 = 'Year 3';
        $year4 = 'Year 4';


        if($request->year == $year4){
            $year = $year4;
            $s = 4;
        }
        else if($request->year == $year3){
            $year = $year3;
            $s = 3;
        }
        else if($request->year == $year2){
            $year = $year2;
            $s = 2;
        }
        else{
            $year = $year1;
            $s = 1;
        }
        $student = DB::SELECT("SELECT
     students.studentID,
                                    students.ID,
                                    students.Firstname,
                                    students.Lastname,
                                    students.Sex,
                                    students.DOB,
                                    students.POB
                                    FROM students
                                    WHERE students.YearID = '{$s}'");
       return view('index',compact('student','year'));
    }

    public function search(Request $request)
    {
        $year1 = 'Year 1';
        $year2 = 'Year 2';
        $year3 = 'Year 3';
        $year4 = 'Year 4';


        if($request->year == $year4){
            $year = $year4;
        }
        else if($request->year == $year3){
            $year = $year3;
        }
        else if($request->year == $year2){
            $year = $year2;
        }
       else {
            $year = $year1;
        }
        $get = $request->search;
        $student = portal::Where('ID','LIKE','%'.$get.'%')
            ->orWhere('Firstname','LIKE','%'.$get.'%')
            ->orWhere('Lastname','LIKE','%'.$get.'%')
            ->get();
        return view('index',compact('student','year'));
    }

    public function timeTable(){
        return view('timeTable');
    }
    public function midterm(Request $request){
        $year1 = 'Year 1';
        $year2 = 'Year 2';
        $year3 = 'Year 3';
        $year4 = 'Year 4';


        if($request->yearm == $year4){
            $year = $year4;
            $s = 4;
        }
        else if($request->yearm == $year3){
            $year = $year3;
            $s = 3;
        }
        else if($request->yearm  == $year2){
            $year = $year2;
            $s = 2;
        }
        else{
            $year = $year1;
            $s = 1;
        }
       $midterm = DB::SELECT("SELECT
       students.ID,
       students.Firstname,
       students.Lastname,
       students.Sex,
       subjects.subjectName,
       midterm.Homework,
       midterm.Notebook,
       midterm.ClassParticipation,
       midterm.Assignment,
       midterm.Presentation,
       midterm.score
       FROM students
       INNER JOIN
       midterm
       ON
       students.studentID = midterm.midtermID
       INNER JOIN
       subjects
       ON
       subjects.subjectID = midterm.midtermID
       WHERE students.yearID = '{$s}'
           ");
        return view('midterm',compact('year','midterm','s'));
    }
    public function news(){
        return view('new');
    }
    public function final(Request $request){
        $year1 = 'Year 1';
        $year2 = 'Year 2';
        $year3 = 'Year 3';
        $year4 = 'Year 4';

        if($request->yearf == $year4){
            $year = $year4;
            $s = 4;
        }
        else if($request->yearf == $year3){
            $year = $year3;
            $s = 3;
        }
        else if($request->yearf == $year2){
            $year = $year2;
            $s = 2;
        }
        else {
            $year = $year1;
            $s = 1;
        }

        $final = DB::SELECT("SELECT
       students.ID,
       students.Firstname,
       students.Lastname,
       students.Sex,
       subjects.subjectName,
       midterm.Score,
       finals.score
       FROM students
       INNER JOIN
       midterm
       ON
       students.studentID = midterm.midtermID
       INNER JOIN
        finals
       ON
        students.studentID = finals.finalID
       INNER JOIN
       subjects
       ON
       subjects.subjectID = midterm.midtermID
       WHERE students.yearID = '{$s}'
        ");
        return view('score',compact('year','final'));
    }
}
