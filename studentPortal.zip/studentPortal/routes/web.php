<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\portalController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('student',[portalController::class,'student']);
Route::get('news',[portalController::class ,'news']);
Route::get('timeTable',[portalController::class, 'timeTable']);
Route::get('final',[portalController::class, 'final']);
Route::get('midterm',[portalController::class, 'midterm']);
Route::get('profile/{id}',[portalController::class, 'show']);
Route::get('/search',[portalController::class,'search']);
//login
Route::get('/',[portalController::class,'index']);
Route::post('checklogin', [portalController::class,'checklogin']);
Route::get('successlogin', [portalController::class,'successlogin']);
Route::get('logout', [portalController::class,'logout']);
