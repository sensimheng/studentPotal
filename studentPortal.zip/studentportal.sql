-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2022 at 03:39 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `detail`
--

CREATE TABLE `detail` (
  `id` int(11) NOT NULL,
  `Firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `yearID` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `POB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Semester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Shift` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PhoneNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `detail`
--

INSERT INTO `detail` (`id`, `Firstname`, `Lastname`, `Sex`, `yearID`, `DOB`, `POB`, `Address`, `Semester`, `Shift`, `PhoneNumber`, `Email`, `created_at`, `updated_at`) VALUES
(1, 'Kakashi', 'Hatake', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'kakashi@gmail.com', NULL, NULL),
(2, 'Pha', 'botum', 'Female', 1, '2022-11-15', 'PP', 'PP', '1', 'Afternoon', '099', 'botum@gmail.com', NULL, NULL),
(3, 'Madara', 'Shimada', 'Male', 1, '2022-11-15', 'PP', 'PP', '2', 'Afternoon', '099', 'madara@gmail.com', NULL, NULL),
(4, 'Sey', 'Ha', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(5, 'Por', 'Porta', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Afternoon', '099', 'A@gmail.com', NULL, NULL),
(6, 'Li', 'Nita', 'Female', 2, '2022-11-15', 'PP', 'PP', '2', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(7, 'Bong', 'Sey', 'Male', 2, '2022-11-15', 'PP', 'PP', '1', 'Afternoon', '099', 'A@gmail.com', NULL, NULL),
(8, 'Ino', 'Suke', 'Male', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(9, 'Pov ', 'Nata', 'Female', 2, '2022-11-15', 'PP', 'PP', '2', 'Afternoon', '099', 'A@gmail.com', NULL, NULL),
(10, 'Pov ', 'Soriya', 'Female', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(11, 'Hong ', 'ChanTha', 'Female', 3, '2022-11-15', 'PP', 'PP', '2', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(12, 'Seng', 'Dara', 'Male', 3, '2022-11-15', 'PP', 'PP', '1', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(13, 'Hour', 'Nata', 'Female', 3, '2022-11-15', 'PP', 'PP', '2', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(14, 'Sen', 'Simheng', 'Male', 3, '2022-11-15', 'PP', 'PP', '1', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(15, 'Chim', 'LySang', 'Female', 3, '2022-11-15', 'PP', 'PP', '1', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(16, 'Pov', 'Naroth', 'Male', 4, '2022-11-15', 'PP', 'PP', '2', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(17, 'Sok', 'Socheat', 'Male', 4, '2022-11-15', 'PP', 'PP', '1', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(18, 'Penh ', 'Dana', 'Male', 4, '2022-11-15', 'PP', 'PP', '2', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(19, 'Heng', 'Harty', 'Male', 4, '2022-11-15', 'PP', 'PP', '1', 'Evening', '099', 'A@gmail.com', NULL, NULL),
(20, 'Heng', 'Dara', 'Male', 4, '2022-11-15', 'PP', 'PP', '2', 'Evening', '099', 'A@gmail.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `finals`
--

CREATE TABLE `finals` (
  `finalID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `subjectID` int(11) NOT NULL,
  `yearID` int(11) NOT NULL,
  `score` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `finals`
--

INSERT INTO `finals` (`finalID`, `studentID`, `subjectID`, `yearID`, `score`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 40, NULL, NULL),
(2, 1, 1, 1, 40, NULL, NULL),
(4, 1, 1, 1, 40, NULL, NULL),
(5, 1, 1, 1, 40, NULL, NULL),
(6, 1, 1, 1, 40, NULL, NULL),
(7, 1, 1, 1, 40, NULL, NULL),
(8, 1, 1, 1, 40, NULL, NULL),
(9, 1, 1, 1, 40, NULL, NULL),
(10, 1, 1, 1, 40, NULL, NULL),
(11, 1, 1, 1, 40, NULL, NULL),
(12, 1, 1, 1, 40, NULL, NULL),
(13, 1, 1, 1, 40, NULL, NULL),
(14, 1, 1, 1, 40, NULL, NULL),
(15, 1, 1, 1, 40, NULL, NULL),
(16, 1, 1, 1, 40, NULL, NULL),
(17, 1, 1, 1, 40, NULL, NULL),
(18, 1, 1, 1, 40, NULL, NULL),
(19, 1, 1, 1, 40, NULL, NULL),
(20, 1, 1, 1, 40, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `midterm`
--

CREATE TABLE `midterm` (
  `midtermID` int(11) NOT NULL,
  `studentID` int(11) NOT NULL,
  `subjectID` int(11) NOT NULL,
  `yearID` int(11) NOT NULL,
  `Homework` int(11) NOT NULL,
  `Notebook` int(11) NOT NULL,
  `ClassParticipation` int(11) NOT NULL,
  `Assignment` int(11) NOT NULL,
  `Presentation` int(11) NOT NULL,
  `Score` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `midterm`
--

INSERT INTO `midterm` (`midtermID`, `studentID`, `subjectID`, `yearID`, `Homework`, `Notebook`, `ClassParticipation`, `Assignment`, `Presentation`, `Score`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(2, 2, 2, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(3, 3, 3, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(4, 4, 4, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(5, 5, 5, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(6, 6, 6, 2, 10, 5, 9, 17, 15, 20, NULL, NULL),
(7, 7, 7, 2, 10, 5, 9, 17, 15, 20, NULL, NULL),
(8, 3, 8, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(9, 4, 9, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(10, 5, 10, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(11, 11, 11, 3, 10, 5, 9, 17, 15, 20, NULL, NULL),
(12, 12, 12, 3, 10, 5, 9, 17, 15, 20, NULL, NULL),
(13, 13, 3, 3, 10, 5, 9, 17, 15, 20, NULL, NULL),
(14, 14, 14, 3, 10, 5, 9, 17, 15, 20, NULL, NULL),
(15, 5, 5, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(16, 6, 6, 2, 10, 5, 9, 17, 15, 20, NULL, NULL),
(17, 7, 7, 2, 10, 5, 9, 17, 15, 20, NULL, NULL),
(18, 3, 8, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(19, 4, 9, 1, 10, 5, 9, 17, 15, 20, NULL, NULL),
(20, 5, 10, 1, 10, 5, 9, 17, 15, 20, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2022_11_09_071508_create_years_table', 1),
(3, '2022_11_09_071634_create_students_table', 1),
(4, '2022_11_09_071649_create_subjects_table', 1),
(5, '2022_11_09_071820_create_finals_table', 1),
(6, '2022_11_09_071833_create_midterm_table', 1),
(7, '2022_11_09_072031_create_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentID` int(11) NOT NULL,
  `ID` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `yearID` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `POB` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Semester` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Shift` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `PhoneNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentID`, `ID`, `Firstname`, `Lastname`, `Sex`, `yearID`, `DOB`, `POB`, `Address`, `Semester`, `Shift`, `PhoneNumber`, `Email`, `created_at`, `updated_at`) VALUES
(1, 'A1', 'Kakashi', 'Hatake', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(2, 'A2', 'Pha', 'Botum', 'Female', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(3, 'A3', 'Madara', 'Shimada', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(4, 'A4', 'Sey', 'Ha', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(5, 'A5', 'Por', 'Porta', 'Male', 1, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(6, 'B1', 'Li', 'Nita', 'Female', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(7, 'B2', 'Bong', 'Sey', 'Male', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(8, 'B3', 'Ino', 'Suke', 'Male', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(9, 'B4', 'Pov', 'Nata', 'Female', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(10, 'B5', 'Pov ', 'Soriya', 'Female', 2, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(11, 'C1', 'Hong', 'ChanTha', 'Female', 3, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(12, 'C2', 'Seng', 'Dara', 'Male', 3, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(13, 'C3', 'Hour', 'Data', 'Female', 3, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(14, 'C4', 'Sen', 'Simheng', 'Male', 3, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(15, 'C5', 'Chim', 'Lysang', 'Female', 3, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(16, 'D1', 'Pov', 'Naroth', 'Male', 4, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(17, 'D2', 'Sok', 'Socheat', 'Female', 4, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(18, 'D3', 'Penh', 'Dana', 'Female', 4, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(19, 'D4', 'Heng', 'Harty', 'Female', 4, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL),
(20, 'D5', 'Heng', 'Dara', 'Male', 4, '2022-11-15', 'PP', 'PP', '1', 'Morning', '099', 'A@gmail.com', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subjectID` int(11) NOT NULL,
  `yearID` int(11) NOT NULL,
  `subjectName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subjectID`, `yearID`, `subjectName`, `created_at`, `updated_at`) VALUES
(1, 1, 'C++', NULL, NULL),
(2, 1, 'English For Computer I', NULL, NULL),
(3, 1, 'Network', NULL, NULL),
(4, 1, 'Design', NULL, NULL),
(5, 1, 'Economy', NULL, NULL),
(6, 2, 'C++ II', NULL, NULL),
(7, 2, 'English For Computer II', NULL, NULL),
(8, 2, 'Network II', NULL, NULL),
(9, 2, 'Web I', NULL, NULL),
(10, 2, 'Design II', NULL, NULL),
(11, 3, 'C#', NULL, NULL),
(12, 3, 'Database ', NULL, NULL),
(13, 3, 'Java I', NULL, NULL),
(14, 3, 'Ecommerce', NULL, NULL),
(15, 3, 'System Analysis', NULL, NULL),
(16, 4, 'Java II', NULL, NULL),
(17, 4, 'Oracle', NULL, NULL),
(18, 4, 'Mobile dev', NULL, NULL),
(19, 4, 'Network Administrator', NULL, NULL),
(20, 4, 'OOP II', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `user_type`, `password`, `created_at`, `updated_at`) VALUES
(1, 'teacher', 'Teacher', '111111', NULL, NULL),
(2, 'heng\r\n', 'Student', '111111', NULL, NULL),
(3, 'lysang\r\n', 'Student', '111111', NULL, NULL),
(4, 'roth\r\n', 'Student', '111111', NULL, NULL),
(5, 'rotha', 'Student', '111111', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `yearID` int(11) NOT NULL,
  `yearTitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `years`
--

INSERT INTO `years` (`yearID`, `yearTitle`, `created_at`, `updated_at`) VALUES
(1, 'Year1', NULL, NULL),
(2, 'Year2', NULL, NULL),
(3, 'Year3', NULL, NULL),
(4, 'Year4', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `students_yearid_foreign` (`yearID`);

--
-- Indexes for table `finals`
--
ALTER TABLE `finals`
  ADD PRIMARY KEY (`finalID`),
  ADD KEY `finals_studentid_foreign` (`studentID`),
  ADD KEY `finals_subjectid_foreign` (`subjectID`),
  ADD KEY `finals_yearid_foreign` (`yearID`);

--
-- Indexes for table `midterm`
--
ALTER TABLE `midterm`
  ADD PRIMARY KEY (`midtermID`),
  ADD KEY `midterm_studentid_foreign` (`studentID`),
  ADD KEY `midterm_subjectid_foreign` (`subjectID`),
  ADD KEY `midterm_yearid_foreign` (`yearID`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentID`),
  ADD KEY `students_yearid_foreign` (`yearID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subjectID`),
  ADD KEY `subjects_yearid_foreign` (`yearID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`yearID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail`
--
ALTER TABLE `detail`
  ADD CONSTRAINT `detail_ibfk_1` FOREIGN KEY (`yearID`) REFERENCES `years` (`yearID`) ON DELETE CASCADE;

--
-- Constraints for table `finals`
--
ALTER TABLE `finals`
  ADD CONSTRAINT `finals_studentid_foreign` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `finals_subjectid_foreign` FOREIGN KEY (`subjectID`) REFERENCES `subjects` (`subjectID`) ON DELETE CASCADE,
  ADD CONSTRAINT `finals_yearid_foreign` FOREIGN KEY (`yearID`) REFERENCES `years` (`yearID`) ON DELETE CASCADE;

--
-- Constraints for table `midterm`
--
ALTER TABLE `midterm`
  ADD CONSTRAINT `midterm_studentid_foreign` FOREIGN KEY (`studentID`) REFERENCES `students` (`studentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `midterm_subjectid_foreign` FOREIGN KEY (`subjectID`) REFERENCES `subjects` (`subjectID`) ON DELETE CASCADE,
  ADD CONSTRAINT `midterm_yearid_foreign` FOREIGN KEY (`yearID`) REFERENCES `years` (`yearID`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_yearid_foreign` FOREIGN KEY (`yearID`) REFERENCES `years` (`yearID`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_yearid_foreign` FOREIGN KEY (`yearID`) REFERENCES `years` (`yearID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
